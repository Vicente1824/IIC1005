"""
Hola este es modulo principal,
el codigo que al ejecutar pondra en marcha nuestro juego
"""
import scenes.game as GameScene

'''Inicio la escena de mi juego'''
GameScene.gameLoop()

