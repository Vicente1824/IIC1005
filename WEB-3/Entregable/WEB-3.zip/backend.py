from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

class CV(BaseModel):
    nombre: str
    titulo: str
    celular: str
    email: str
    trabajo_institucion: str
    estudios_institucion: str

@app.get("/first-curriculum")
def give_first_curriculum():
    with open("curriculums.txt", "r", encoding = "utf-8") as archivo:
        info = archivo.readlines()
    info = info[0].strip().split(";")
    cv_pedido = {}
    cv_pedido["nombre"] = f"{info[0]} {info[1]}"
    cv_pedido["titulo"] = info[2]
    cv_pedido["celular"] = info[3]
    cv_pedido["email"] = info[4]
    cv_pedido["trabajo_institucion"] = info[5]
    cv_pedido["estudios_institucion"] = info[6]
    return cv_pedido

@app.get("/name-curriculums")
def conseguir_nombres() -> list:
    with open('curriculums.txt', 'r', encoding = "utf-8") as archivo:
        lista_nombres = []
        for linea in archivo:
           lista =  linea.split(";")
           lista_nombres.append(lista[0])
    return lista_nombres

@app.get("/curriculum/{nombre}")
def conseguir_cv(nombre):
    with open('curriculums.txt', 'r', encoding = "utf-8") as archivo:
        for linea in archivo:
            lista =  linea.split(";")
            if lista[0] == nombre:
                diccionario = {"nombre": f"{lista[0]} {lista[1]}", "titulo": lista[2],
                               "celular": lista[3], "email": lista[4],
                               "trabajo_institucion": lista[5], "estudios_institucion": lista[6]}
                return diccionario
    return "ERROR NO ENCONTRÉ NADA"

@app.post("/curriculum")
def guardar_cv(cv: CV):
    with open('curriculums.txt', 'a', encoding = "utf-8") as archivo:
        texto = ""
        nombre = (cv.nombre.split(" "))[0]
        apellido = (cv.nombre.split(" "))[1]
        titulo = cv.titulo
        celular = cv.celular
        email = cv.email
        trabajo_institucion = cv.trabajo_institucion
        estudios_institucion = cv.estudios_institucion
        texto = nombre + ";" + apellido + ";" + titulo + ";" + celular + ";" + email + ";" + trabajo_institucion + ";" + estudios_institucion
        print(texto, file=archivo)
    
lista_atributos = list(CV.__annotations__.keys())